import streamlit as st

from Contributor import Contributor

import generator
from validateProfile import check_about_section

def is_stackoverflow_link(link):
    return link.startswith("https://stackoverflow.com/users/")

def main():

    contributors = []
    st.session_state.setdefault("generated_code", None)
    st.title("Please provide a link to your Stack Overflow account for verification")
    stackoverflow_link = st.text_input("Enter your Stack Overflow account link:")

    if stackoverflow_link:
        if is_stackoverflow_link(stackoverflow_link):
            newContributor = Contributor(stackoverflow_link)
            contributors.append(newContributor)
            st.write("Good!")
            st.write("Now please, post this in your about section in your profile:")
            if st.session_state.generated_code is None:
                newContributor.set_unique_code(generator.generate_unique_random_string())
                st.session_state.generated_code = st.session_state.newContributor.get_unique_code()

                print(st.session_state.generated_code)
            st.code(f"Code: {st.session_state.generated_code}")
            if st.button("Verify"):
                print(newContributor.unique_code + "\n-----------------------------------")
                if check_about_section(newContributor.stackoverflow_account_link, newContributor.get_unique_code()):
                    st.write("Success! Your profile has been verified.")
                else:
                    st.write("Please try again. :(")
                st.session_state.generated_code = None


        else:
            st.warning("This is not a valid Stack Overflow account link. Please enter a valid link.")
            st.text("Example: https://stackoverflow.com/users/1234567/your-username")

if __name__ == "__main__":
    main()
